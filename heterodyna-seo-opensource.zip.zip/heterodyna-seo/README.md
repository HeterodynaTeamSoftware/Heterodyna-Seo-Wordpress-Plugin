# Heterodyna SEO

Open-source WordPress SEO toolkit.

## Open-source build

This package has remote commercial licensing and remote status reporting disabled.
All plugin features are available without a license key.

## Privacy

The plugin does not include a built-in license server endpoint and does not send a license activation request or remote status reporting.
External requests may still happen only for user-configured integrations or explicit features, for example PageSpeed Insights, social integrations, sitemap fetching, or URL imports.

## Install

1. Upload the `heterodyna-seo` plugin directory to `wp-content/plugins/`.
2. Activate **Heterodyna SEO** in WordPress Admin.
3. Open **Heterodyna SEO → Open Source** to verify the build status.

## License

GPL-2.0-or-later.
