<?php if (!defined('ABSPATH')) { exit; } ?>
  </div><!-- .het-seo-content -->
  <div class="het-seo-foot">
    <span>Heterodyna SEO</span> • <span>AI Auto + SEO Core</span>
  </div>
</div><!-- .het-seo-shell -->
